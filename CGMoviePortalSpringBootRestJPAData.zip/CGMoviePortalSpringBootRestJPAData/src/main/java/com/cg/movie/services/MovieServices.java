package com.cg.movie.services;

import java.util.List;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.exceptions.MovieDetailsNotfoundException;
import com.cg.movie.exceptions.SongDetailsNotfoundException;

public interface MovieServices {
	Movie acceptMovieDetails(Movie movie);
	Movie getMovieDetails(int movieId) throws MovieDetailsNotfoundException ;
	Song acceptSongDetails(Song song);
	Song getSongDetails(int songId) throws SongDetailsNotfoundException ;
	List<Song> getAllSongDetails(int movieId);
}
